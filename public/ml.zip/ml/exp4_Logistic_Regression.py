# Experiment 4 – Logistic Regression

import pandas as pd
from sklearn.linear_model import LogisticRegression
import matplotlib.pyplot as plt
import numpy as np

# Create dataset directly
df = pd.DataFrame({
    "hours": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    "pass":  [0, 0, 0, 0, 1, 1, 1, 1, 1, 1]
})

# Select input and target
X = df[["hours"]]
y = df["pass"]

# Train model
model = LogisticRegression()
model.fit(X, y)

# Generate sigmoid curve
X_test = np.linspace(
    X["hours"].min(),
    X["hours"].max(),
    300
).reshape(-1, 1)

y_prob = model.predict_proba(X_test)[:, 1]

# Plot graph
plt.figure(figsize=(8, 6))
plt.scatter(X["hours"], y, color="black", label="Actual Data")
plt.plot(X_test, y_prob, color="red", linewidth=2,
         label="Sigmoid Curve")

plt.xlabel("Hours")
plt.ylabel("Probability of Passing")
plt.title("Logistic Regression Sigmoid Curve")
plt.legend()
plt.grid(True, linestyle="--", alpha=0.5)
plt.show()


# Run in VS Code
# Install the required libraries:
# pip install pandas numpy matplotlib scikit-learn


# Run the experiment:
# python exp4_Logistic_Regression.py