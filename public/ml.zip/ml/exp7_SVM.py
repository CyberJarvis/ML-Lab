# Experiment 7 – Support Vector Machine (SVM)


import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.inspection import DecisionBoundaryDisplay
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

# Load Iris dataset
iris = load_iris()
X = iris.data[:, :2]
y = iris.target

# Split dataset (80% training, 20% testing)
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=10,
    stratify=y
)

# Create SVM model with linear kernel
model = make_pipeline(
    StandardScaler(),
    SVC(kernel="linear")
)

# Train the model
model.fit(X_train, y_train)

# Evaluate model
pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, pred))

# Display decision boundaries
DecisionBoundaryDisplay.from_estimator(
    model,
    X_train,
    response_method="predict",
    cmap=plt.cm.Paired
)

# Plot training data
plt.scatter(
    X_train[:, 0],
    X_train[:, 1],
    c=y_train,
    edgecolor="k"
)

plt.xlabel("Sepal Length (cm)")
plt.ylabel("Sepal Width (cm)")
plt.title("SVM Classification - Iris Dataset")
plt.show()


# Run in VS Code
# Install the libraries:
# pip install matplotlib scikit-learn


# Run the program:
# python exp7_SVM.py