# Experiment 8 – Graph Based Clustering: Divisive Clustering


import numpy as np

# Objects
objects = ["a", "b", "c", "d", "e"]

# Distance matrix
distance = np.array([
    [0, 9, 3, 6, 11],
    [9, 0, 7, 5, 10],
    [3, 7, 0, 9, 2],
    [6, 5, 9, 0, 8],
    [11, 10, 2, 8, 0]
], dtype=float)

# Start with one cluster containing all objects
clusters = [list(range(len(objects)))]

print("Divisive Hierarchical Clustering\n")

while any(len(c) > 1 for c in clusters):

    # Select the cluster with the largest diameter
    candidates = [c for c in clusters if len(c) > 1]

    chosen = max(
        candidates,
        key=lambda c: max(distance[i, j] for i in c for j in c)
    )

    clusters.remove(chosen)

    # Find the farthest pair
    i, j = max(
        ((i, j) for i in chosen for j in chosen if i < j),
        key=lambda pair: distance[pair[0], pair[1]]
    )

    # Create two new clusters
    left, right = [i], [j]

    # Assign remaining objects to the nearer seed
    for p in chosen:
        if p not in (i, j):
            if distance[p, i] <= distance[p, j]:
                left.append(p)
            else:
                right.append(p)

    clusters.extend([left, right])

    # Display current clusters
    print([[objects[k] for k in c] for c in clusters])

# Run in VS Code
# Install the required libraries:
# pip install numpy


# Run the experiment:
# python exp8_Divisive.py