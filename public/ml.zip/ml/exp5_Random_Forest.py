# Experiment 5 – Ensemble Learning: Random Forest

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

# Load Iris dataset
iris = load_iris()
X = iris.data
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# Create Random Forest model
model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

# Train the model
model.fit(X_train, y_train)

# Predict test data
pred = model.predict(X_test)

# Evaluate model
print("Accuracy:", accuracy_score(y_test, pred))
print("\nClassification Report:")
print(classification_report(
    y_test,
    pred,
    target_names=iris.target_names
))


# Run in VS Code
# Install the libraries:
# pip install scikit-learn


# Run the experiment:
# python exp5_Random_Forest.py