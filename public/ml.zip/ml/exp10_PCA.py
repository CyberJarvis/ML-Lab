

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Create dataset
df = pd.DataFrame({
    "Math": [80, 85, 90, 75, 88, 92, 78, 95],
    "Science": [82, 87, 91, 73, 89, 94, 80, 96],
    "English": [70, 75, 82, 68, 78, 85, 72, 88]
})

# Convert DataFrame to NumPy array
X = df.values

# Center the data
X_centered = X - X.mean(axis=0)

# Calculate covariance matrix
cov = np.cov(X_centered, rowvar=False)

# Calculate eigenvalues and eigenvectors
values, vectors = np.linalg.eigh(cov)

# Sort in descending order
order = np.argsort(values)[::-1]
values = values[order]
vectors = vectors[:, order]

# Calculate explained variance
explained = values / values.sum()

# Project data onto first two principal components
X_pca = X_centered @ vectors[:, :2]

# Display results
print("Eigenvalues:", values)
print("Explained Variance (%):", explained * 100)
print("First Two PC Coordinates:\n", np.round(X_pca, 2))

# Plot PCA results
plt.scatter(X_pca[:, 0], X_pca[:, 1])
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("PCA: First Two Principal Components")
plt.grid(True)
plt.show()


# Run in VS Code
# 1. Install the required libraries:
# pip install numpy pandas matplotlib


# 2. Run the program:
# python exp10_PCA.py