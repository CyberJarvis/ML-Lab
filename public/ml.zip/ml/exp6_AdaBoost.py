# Experiment 6 – Ensemble Learning: AdaBoost

import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix

# Create dataset
df = pd.DataFrame({
    "Salary": [
        "<50k", "<50k", ">50k", "<50k", ">50k", "<50k",
        ">50k", "<50k", ">50k", "<50k", ">50k", "<50k"
    ],
    "Credit": [
        "Bad", "Good", "Good", "Normal", "Bad", "Good",
        "Normal", "Bad", "Good", "Normal", "Good", "Bad"
    ],
    "Approval": [
        "No", "No", "Yes", "Yes", "No", "Yes",
        "Yes", "No", "Yes", "Yes", "Yes", "No"
    ]
})

# Encode categorical values into numbers
for col in df.columns:
    df[col] = LabelEncoder().fit_transform(df[col])

# Select features and target
X = df[["Salary", "Credit"]]
y = df["Approval"]

# Split dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

# Create a weak learner (decision stump)
stump = DecisionTreeClassifier(max_depth=1, random_state=42)

# Create and train AdaBoost model
model = AdaBoostClassifier(
    estimator=stump,
    n_estimators=20,
    random_state=42
)

model.fit(X_train, y_train)

# Predict test data
pred = model.predict(X_test)

# Evaluate model
print("Accuracy:", accuracy_score(y_test, pred))
print("Confusion Matrix:")
print(confusion_matrix(y_test, pred))



# Run in VS Code
# Install the required libraries:
# pip install pandas scikit-learn


# Run the experiment:
# python exp6_AdaBoost.py