import numpy as np
from sklearn.mixture import GaussianMixture

# Dataset
x = np.array([
    2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
    20, 21, 22, 23, 24, 25, 26, 27, 28, 29
], dtype=float).reshape(-1, 1)

# Create and train the GMM model
model = GaussianMixture(
    n_components=2,
    random_state=42,
    n_init=5
)

model.fit(x)

# Predict clusters
pred = model.predict(x)

# Display results
print("Means:", model.means_.ravel())
print("Variances:", model.covariances_.ravel())
print("Weights:", model.weights_)

print("\nCluster Assignments:")
for value, cluster in zip(x.ravel(), pred):
    print(int(value), "-> Cluster", cluster + 1)


# Open the VS Code terminal and run:
# pip install numpy matplotlib scikit-learn
# Run the program
# python exp9_EM.py
