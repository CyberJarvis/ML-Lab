from sklearn.datasets import load_linnerud
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

d = load_linnerud()
X_train, X_test, y_train, y_test = train_test_split(d.data, d.target, test_size=0.2, random_state=42)
m = LinearRegression().fit(X_train, y_train)
p = m.predict(X_test)
print("Coefficients:", m.coef_, "Intercept:", m.intercept_)
print("Predictions:\n", p)
print("R2 (uniform average):", r2_score(y_test, p))
