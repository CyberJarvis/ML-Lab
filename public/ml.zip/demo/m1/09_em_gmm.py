from sklearn.datasets import load_iris
from sklearn.mixture import GaussianMixture
import numpy as np

X = load_iris().data

m = GaussianMixture(n_components=3, random_state=42, n_init=10)
m.fit(X)

pred = m.predict(X)

print("Shape:", X.shape)
print("Cluster counts:", np.bincount(pred, minlength=3))
print("Total:", len(pred))
print("Means:\n", m.means_)
