from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

d = load_diabetes()
X, y = d.data[:, [2]], d.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
m = LinearRegression().fit(X_train, y_train)
p = m.predict(X_test)
print("Slope:", m.coef_[0], "Intercept:", m.intercept_)
print("MSE:", mean_squared_error(y_test, p), "R2:", r2_score(y_test, p))
print("Prediction:", m.predict([[0.05]])[0])

plt.scatter(X_test, y_test, color='blue', label='Actual')
plt.plot(X_test, p, color='red', label='Fitted line')
plt.xlabel("BMI"); plt.ylabel("Disease progression")
plt.title("Simple Linear Regression"); plt.legend()
plt.show()
