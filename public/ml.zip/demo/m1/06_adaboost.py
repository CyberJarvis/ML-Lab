from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

d = load_iris()
X_train, X_test, y_train, y_test = train_test_split(
    d.data, d.target, test_size=0.2, random_state=42, stratify=d.target)
m = AdaBoostClassifier(estimator=DecisionTreeClassifier(max_depth=1), n_estimators=50,
                       random_state=42).fit(X_train, y_train)
p = m.predict(X_test)
print("Accuracy:", accuracy_score(y_test, p))
print("Feature importance:", m.feature_importances_)
