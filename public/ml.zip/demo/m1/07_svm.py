from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, confusion_matrix

d = load_iris()
X_train, X_test, y_train, y_test = train_test_split(
    d.data, d.target, test_size=0.2, random_state=42, stratify=d.target)
m = make_pipeline(StandardScaler(), SVC()).fit(X_train, y_train)
p = m.predict(X_test)
print("Accuracy:", accuracy_score(y_test, p))
print("Confusion matrix:\n", confusion_matrix(y_test, p))
