import networkx as nx
import matplotlib.pyplot as plt

G = nx.Graph()

edges = [
    ('A', 'B'), ('A', 'C'), ('B', 'C'),('C', 'D'), ('D', 'E'), ('D', 'F'), ('E', 'F'),('F', 'G'), ('G', 'H'), ('G', 'I'), ('H', 'I')
]

G.add_edges_from(edges)
plt.figure(figsize=(8, 5))
pos = nx.spring_layout(G, seed=42)
nx.draw(
    G, pos, with_labels=True,
    node_color='lightblue',
    node_size=800, font_weight='bold'
)
plt.title("Original Graph")
plt.show()

from networkx.algorithms.community import girvan_newman

communities_generator = girvan_newman(G)
communities = next(communities_generator)
for i, community in enumerate(communities, start=1):
    print(f"Cluster {i}: {sorted(community)}")

cluster_colors = ['lightgreen', 'salmon', 'gold', 'violet']
node_colors = {}

for i, community in enumerate(communities):
    for node in community:
        node_colors[node] = cluster_colors[i % len(cluster_colors)]

plt.figure(figsize=(8, 5))
nx.draw(
    G, pos, with_labels=True,
    node_color=[node_colors[node] for node in G.nodes()],
    node_size=800, font_weight='bold'
)
plt.title("Graph-Based Divisive Clustering")
plt.show()
