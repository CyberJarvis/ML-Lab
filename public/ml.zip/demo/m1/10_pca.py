from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

X = StandardScaler().fit_transform(load_iris().data)
p = PCA(n_components=2)
X_reduced = p.fit_transform(X)
print("Original shape:", X.shape, "Reduced shape:", X_reduced.shape)
print("Explained variance ratio:", p.explained_variance_ratio_)
print("Total variance retained (%):", p.explained_variance_ratio_.sum() * 100)
