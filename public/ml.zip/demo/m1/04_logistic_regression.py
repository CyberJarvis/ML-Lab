from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix

d = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    d.data, d.target, test_size=0.2, random_state=42, stratify=d.target)
m = LogisticRegression(max_iter=10000).fit(X_train, y_train)

p = m.predict(X_test)
print("Accuracy:", accuracy_score(y_test, p))
print("Confusion matrix:\n", confusion_matrix(y_test, p))
print("Class probabilities:", m.predict_proba(X_test[:3]))
